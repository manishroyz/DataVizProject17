class LineChart {
	
	
	
		
	constructor(data){
		
		 let divLineChart = d3.select("#line-chart").classed("content", true);
		   this.margin = {top: 20, right: 200, bottom: 100, left: 50};
        
	
	
	 this.svgWidth = 960 - this.margin.left - this.margin.right;
	  this.svgHeight = 500 - this.margin.top - this.margin.bottom;
       
        this.svg = divLineChart.append("svg")
            .attr("width",this.svgWidth+ this.margin.left + this.margin.right)
            .attr("height",this.svgHeight+ this.margin.top + this.margin.bottom)
			.attr("transform", "translate(" + this.margin.right + "," + this.margin.top + ")");
			//.classed("line-chrt",true);
			
			
			let colors = [
	'steelblue',
	'green',
	'red',
	'purple'
]
			
		
	};
	
	update(selectedStationsData){
		
	

let mySelf = this;

			d3.csv("data/BostonOrderedDataset.csv", function(error, data) {
				
				
				let startDate = selectedStationsData[2];
				let endDate = selectedStationsData[3];
				
				let neededData = new Array();
						
						data.forEach(function(d) {
						
					if( (d.start_station_id == selectedStationsData[0] || d.start_station_id == selectedStationsData[1]) && (d.end_station_id == selectedStationsData[0] || d.end_station_id == selectedStationsData[1])  && 
			( d.starttime >=  startDate  && d.stoptime <= endDate) )
				 neededData.push(d);
			  });
			 
			 console.log(neededData);
		if(neededData == null ) return true;
		
		
		// tripsWithCount holds the dates as days in the interval selected and their counts as key value pairs
		  let tripsWithCount = d3.nest()
						.key(function(d) { 
						let DateWithoutTime = (new Date(d.starttime).getMonth() + 1) + "/" + new Date(d.starttime).getDate() + "/" + new Date(d.starttime).getFullYear(); 
						return DateWithoutTime;
						})
						.rollup(function(d) { 
						return d3.sum(d, function(g) {return 1; });
						}).entries(neededData);
		     
		
		if(tripsWithCount == null)
			return true;
		else{
			
			let g =	mySelf.svg.append("g")
			.attr("transform", "translate(" + mySelf.margin.right + "," + mySelf.margin.top + ")")
			//.attr("transform","translate(10,200)");
		// parse the date / time
		let parseTime = d3.timeParse("%m/%d/%Y");

			// set the ranges
		let x = d3.scaleTime().range([0, mySelf.svgWidth]);
		let y = d3.scaleLinear().range([mySelf.svgHeight, 0]);

			// define the line
		let valueline = d3.line()
    .x(function(d) { 
	return x(d.key); 
	})
    .y(function(d) { 
	return y(d.value); 
	});
	
	
	
		
			
			
			 // format the data
  tripsWithCount.forEach(function(d) {
      d.key = parseTime(d.key);
      d.value = d.value;
  });
			
			 // Scale the range of the data
  x.domain(d3.extent(tripsWithCount, function(d) { return d.key; }));
  y.domain([0, d3.max(tripsWithCount, function(d) { return d.value; })]);

  // Add the valueline path.
  g.append("path")
      .data([tripsWithCount])
      .attr("class", "line")
      .attr("d", valueline);

  // Add the X Axis
  g.append("g")
      .attr("class", "axis")
      .attr("transform", "translate(0," + mySelf.svgHeight  + ")")
      .call(d3.axisBottom(x)
              .tickFormat(d3.timeFormat("%m-%d-%Y")))
      .selectAll("text")	
        .style("text-anchor", "end")
        .attr("dx", "-.8em")
        .attr("dy", ".15em")
        .attr("transform", "rotate(-65)");

  // Add the Y Axis
 g.append("g")
      .attr("class", "axis")
	 // .attr("transform", "translate(" +mySelf.svgWidth  + ",0)")
      .call(d3.axisLeft(y));

			
			
		}
		
			
		
		
		
	});
	
	
	
	
	
	
}
	
	
	
/////////////////////////////////////////////Hours Line Chart//////////////////////////////////////


	updateHoursLineChart(selectedDays,stationA,stationB){
		
	
			let mySelf = this;

			d3.csv("data/BostonOrderedDataset.csv", function(error, data) {
		
		 
				
				let neededDaysData = new Array();
						
						data.forEach(function(d) {
						
					if( (d.start_station_id == stationA || d.start_station_id == stationB) && (d.end_station_id == stationA || d.end_station_id == stationB)){
						let DateWithoutTime = (d.starttime.split(" "))[0]; 
						
					if( selectedDays.indexOf(DateWithoutTime)  != null && selectedDays.indexOf(DateWithoutTime)  >= 0) 
				 neededDaysData.push(d);
					}
			  });
			 
			 console.log(neededDaysData);
		if(neededDaysData == null ) return true;
		
		
		// tripsWithCount holds the dates as days in the interval selected and their counts as key value pairs
		  let tripsHoursWithCount = d3.nest()
						.key(function(d) { 
						let DatWithTime = (new Date(d.starttime).getMonth() + 1) + "/" + new Date(d.starttime).getDate() + "/" + new Date(d.starttime).getFullYear() + " "+ new Date(d.starttime).getHours(); 
						return DatWithTime;
						})
						.rollup(function(d) { 
						return d3.sum(d, function(g) {return 1; });
						}).entries(neededDaysData);
		     
		
		
		 
			 console.log(tripsHoursWithCount);
		if(tripsHoursWithCount == null)
			return true;
	
	
	tripsHoursWithCount.forEach(function(d) {
	    d.day = d.key.split(" ")[0];
		d.key = d.key.split(" ")[1];
		d.value = d.value;
    });
	
	
	 
	
    // Set the dimensions of the canvas / graph
let margin = {top: 30, right: 20, bottom: 70, left: 50},
    width = 850 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom;


// Adds the svg canvas
let svg = d3.select("body")
    .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
    .append("g")
        .attr("transform", 
              "translate(" + margin.left + "," + margin.top + ")");
			  
// Set the ranges
let x = d3.scaleLinear().range([0, width]).nice(); //d3.scaleBand().rangeRound([0, width]).paddingInner(1);// 
let y = d3.scaleLinear().range([height, 0]);   //d3.scaleBand().rangeRound([height, 0])paddingInner(1);

// Define the line
let priceline = d3.line()	
    .x(function(d) { return x(d.key); })
    .y(function(d) { return y(d.value); });
    

 
		// Scale the range of the data
  
	//x.domain(d3.extent(tripsHoursWithCount, function(d) { return d.key; }));
    y.domain([0, d3.max(tripsHoursWithCount, function(d) { return d.value+1; })]);
	x.domain([0,24]);
     // x.domain(tripsHoursWithCount.map(function(d) {
      //      return d.key;
      //  }));
		//y.domain(tripsHoursWithCount.map(function(d) {
       //     return d.value;
       // }));
	
	
	 // Nest the entries by symbol
    let dataNest = d3.nest()
        .key(function(d) {return d.day;})
        .entries(tripsHoursWithCount);

 
	console.log(dataNest);
	 // set the colour scale
    var color = d3.scaleOrdinal(d3.schemeCategory10);

   let legendSpace = width/dataNest.length; // spacing for the legend

	  // Add the X Axis
  svg.append("g")
      .attr("class", "axis")
      .attr("transform", "translate(0," + height + ")")
	 //  .call(d3.axisBottom(x)
      //        .tickFormat(d3.timeFormat("%H")));
     .call(d3.axisBottom(x));

  // Add the Y Axis
  svg.append("g")
      .attr("class", "axis")
      .call(d3.axisLeft(y));
	  // Loop through each day
    dataNest.forEach(function(d,i) { 
      
		   
        svg.append("path")
            .attr("class", "line")
            .style("stroke", function() { // Add the colours dynamically
                return d.color = color(d.key); })
            .attr("d", priceline(d.values));

        // Add the Legend
        svg.append("text")
            .attr("x", (legendSpace/2)+i*legendSpace)  // space legend
            .attr("y", height + (margin.bottom/2)+ 5)
            .attr("class", "legend")    // style the legend
            .style("fill", function() { // Add the colours dynamically
                return d.color = color(d.key); })
            .text(d.key); 
		

    });


	
			});
	

		
		
	
	
};
		
	
	
	
 
	
	
	
	
	

};
		   
		
	
	
	
	
	
	
	
	
	